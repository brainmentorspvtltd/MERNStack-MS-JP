import React from "react";
import { Button } from "./components/Button";
import { Message } from "./components/Message";



const App = ()=>{
  return (<>
      <Message msg = "Counter App"/>
      <Message msg = "Count value is "/>
      <Button val = "+"/> &nbsp;
      <Button val = "-"/>
    </>)
}
export default App;