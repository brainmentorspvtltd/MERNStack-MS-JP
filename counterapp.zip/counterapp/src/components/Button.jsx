export const Button = (props)=>{
    return (<button>{props.val}</button>)
}