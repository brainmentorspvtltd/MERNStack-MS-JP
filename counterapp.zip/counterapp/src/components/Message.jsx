export const Message = (props)=>{
    return (<h2>{props.msg}</h2>)
}