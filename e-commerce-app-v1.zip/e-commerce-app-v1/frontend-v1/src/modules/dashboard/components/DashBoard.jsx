import React from 'react'
import { Header } from '../../../shared/components/Header'
import { Product } from './Product'

export const DashBoard = () => {
  return (
    <div className = 'container'>
        <Header/>
        <div className='row'>
            <div className = 'col-8'>
                <div className = 'row'>
                    <Product/>
                    <Product/>
                    <Product/>
                </div>
            </div>
            <div className = 'col-4'>

            </div>
        </div>
    </div>
  )
}
