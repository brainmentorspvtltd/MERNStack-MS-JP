import React from 'react'

export const Logo = () => {
  return (
   <span>Pizza Factory</span>
  )
}
