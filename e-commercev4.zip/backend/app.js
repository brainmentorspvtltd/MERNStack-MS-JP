import express from 'express';
const app = express();
app.get('/products',(request, response)=>{
    // Array - Pizzas
    response.send('Products');
})
app.listen(4444, err=>{
    if(err){
        console.log('Server Crash ', err);
    }
    else{
        console.log('Server Up and Running');
    }
})