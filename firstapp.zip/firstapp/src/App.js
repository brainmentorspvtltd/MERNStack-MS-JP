// function App(){
//   return (<h1>Hello React JS</h1>);
// }
// ES6 
// ShortHand
// Pure Function
// Not act as a constructor

import React from "react";

// Lexical this
// const App = ()=>{
//   return React.createElement('div',
//   null,
//   React.createElement('h1',null, 'Hello VDOM'),
//     React.createElement('h2',null, 'Hi VDOM'));

// }

const App = ()=>{
  const message = "Welcome User";
  const isLogin = false;
  const songs = [{name:"Bang Bang",id:1}, {name:"It's My Life",id:2}, {name:"Boom Boom", id:3}];
  return (<div>
<h1>Hello react js </h1>
<h2>Hi react js </h2>
<h3>{message}</h3>
{isLogin?<button>Logout</button>:<button>Login</button>}
<p>List of Songs</p>
    <ul>
    {songs.map((song)=><li key={song.id}>{song.name}</li>)}
    </ul>
</div>);
}
export default App;