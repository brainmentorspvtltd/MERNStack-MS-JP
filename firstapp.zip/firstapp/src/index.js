// Bridge file - Connect App Component (Root Component)

import App from "./App";
import ReactDOM from 'react-dom/client';
// to the HTML (index.html)
const dom = document.getElementById('root');
const divRoot = ReactDOM.createRoot(dom);
divRoot.render(<App/>)