import { DashBoard } from "./modules/dashboard/components/DashBoard";

const App = ()=>{
  return (<DashBoard/>)
}
export default App;