import {createContext} from 'react'
export const CartContext = createContext({cart:[],addInCart:function(product){}})